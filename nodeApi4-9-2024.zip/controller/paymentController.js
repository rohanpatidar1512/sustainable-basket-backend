const crypto = require('crypto');
const axios = require('axios');
require("dotenv").config();

const testpaymentApi = async (req, res) => {
  try {
    console.log("This is a test payment");
    const data = {
      merchantId: "SUSTAINABLEONLINE",
      merchantTransactionId: "MT7850590068188104",
      merchantUserId: "MUID123",
      name: "Sejal",
      amount: 10000,
      redirectUrl: 'http://localhost:3000/order-success',
      redirectMode: 'POST',
      mobileNumber: "7987243298",
      paymentInstrument: {
        type: 'PAY_PAGE'
      }
    };

    const payload = JSON.stringify(data);
    const payloadMain = Buffer.from(payload).toString('base64');
    console.log(payloadMain);
    const keyIndex = 1;
    const string = payloadMain + '/pg/v1/pay' + process.env.SALT_KEY;
    const sha256 = crypto.createHash('sha256').update(string).digest('hex');
    const checksum = sha256 + '###' + keyIndex;

    const options = {
      method: 'POST',
      url: process.env.PHONEPE_API_URL,
      headers: {
        accept: 'application/json',
        'Content-Type': 'application/json',
        'X-VERIFY': checksum
      },
      data: payloadMain
    };
    // const response = await axios.request(options);
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: error.message, success: false });
  }
};

const newPayment = async (req, res) => {
  try {
    const merchantTransactionId = req.body.transactionId;
    const data = {
      merchantId: "SUSTAINABLEONLINE",
      merchantTransactionId: "MT7850590068188104",
      merchantUserId: "MUID123",
      name: "Sejal",
      amount: 10000,
      redirectUrl: 'http://localhost:3000/order-success',
      redirectMode: 'POST',
      mobileNumber: "7987243298",
      paymentInstrument: {
        type: 'PAY_PAGE'
      }
    };

    const payload = JSON.stringify(data);
    const payloadMain = Buffer.from(payload).toString('base64');
    console.log(payloadMain);
    const keyIndex = 1;
    const string = payloadMain + '/pg/v1/pay' + process.env.SALT_KEY;
    const sha256 = crypto.createHash('sha256').update(string).digest('hex');
    const checksum = sha256 + '###' + keyIndex;

    const options = {
      method: 'POST',
      url: process.env.PHONEPE_API_URL,
      headers: {
        accept: 'application/json',
        'Content-Type': 'application/json',
        'X-VERIFY': checksum
      },
      data: payloadMain
    };

    const response = await axios.request(options);

    if (response.data.success === true) {
      res.redirect(response.data.data.instrumentResponse.redirectInfo.url);
    } else {
      res.status(400).send({ success: false, message: 'Payment Failure' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: error.message, success: false });
  }
};

const checkStatus = async (req, res) => {
  try {
    const merchantTransactionId = res.req.body.transactionId;
    const merchantId = process.env.MERCHANT_ID;
    const keyIndex = 1;
    const string = `/pg/v1/status/${merchantId}/${merchantTransactionId}` + process.env.SALT_KEY;
    const sha256 = crypto.createHash('sha256').update(string).digest('hex');
    const checksum = sha256 + "###" + keyIndex;

    const options = {
      method: 'GET',
      url: `https://api.phonepe.com/apis/hermes/pg/v1/status/${merchantId}/${merchantTransactionId}`,
      headers: {
        accept: 'application/json',
        'Content-Type': 'application/json',
        'X-VERIFY': checksum,
        'X-MERCHANT-ID': `${merchantId}`
      }
    };

    const response = await axios.request(options);

    if (response.data.success === true) {
      return res.status(200).send({ success: true, message: "Payment Success" });
    } else {
      return res.status(400).send({ success: false, message: "Payment Failure" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: error.message, success: false });
  }
};

module.exports = {
  newPayment,
  checkStatus,
  testpaymentApi
};
