const express = require('express');
const { addTitle, getAllTitles, updateTitle, getTitleById } = require('../controller/masterDocumentCtrl');
const router = express.Router();

router.post('/add',addTitle);
router.get('/',getAllTitles);
router.get('/:id',getTitleById)
router.put('/:id',updateTitle)

module.exports = router;
