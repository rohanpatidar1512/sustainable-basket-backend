const express = require('express');
//const { authMiddleware } = require('../middlewares/authMiddleware');
const { newPayment, checkStatus, testpaymentApi } = require('../controller/paymentController');
const router = express.Router();


router.post('/new-payment',newPayment)
router.post('/check-status/:txnId', checkStatus);
router.post('/test-api',testpaymentApi)


module.exports = router;